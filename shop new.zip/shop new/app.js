const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Inicializace databáze
const dbPath = path.join(__dirname, 'database', 'eshop.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) console.error("DB Error: ", err.message);
  else console.log("Connected to SQLite database");
});

// Vytvoření tabulek, pokud neexistují
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT,
      is_vip INTEGER
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      description TEXT,
      price REAL,
      imagePath TEXT
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS cart (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      product_id INTEGER,
      quantity INTEGER,
      FOREIGN KEY(user_id) REFERENCES users(id),
      FOREIGN KEY(product_id) REFERENCES products(id)
  )`);
  
  // Vložíme ukázkové produkty, pokud tabulka products neobsahuje žádné záznamy
  db.get("SELECT COUNT(*) AS count FROM products", (err, row) => {
    if (err) console.error(err);
    else if (row.count === 0) {
      const stmt = db.prepare("INSERT INTO products (name, description, price, imagePath) VALUES (?, ?, ?, ?)");
      stmt.run("Produkt 1", "Popis produktu 1", 500, "/images/produkt1.jpg");
      stmt.run("Produkt 2", "Popis produktu 2", 750, "/images/produkt2.jpg");
      stmt.finalize();
      console.log("Inserted sample products");
    }
  });
});

// Přidáváme aktuálně přihlášeného uživatele do lokálních proměnných šablon
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  next();
});

// Routy

// Hlavní přehled produktů
app.get('/', (req, res) => {
  db.all("SELECT * FROM products", (err, products) => {
    if (err) {
      console.error(err);
      res.send("Error loading products");
    } else {
      res.render('index', { products: products });
    }
  });
});

// Registrace
app.get('/register', (req, res) => {
  res.render('register');
});

app.post('/register', (req, res) => {
  const { username, password, is_vip } = req.body;
  const vipValue = is_vip ? 1 : 0;
  const query = "INSERT INTO users (username, password, is_vip) VALUES (?, ?, ?)";
  db.run(query, [username, password, vipValue], function(err) {
    if (err) {
      console.error(err);
      res.send("Registrace: " + err.message);
    } else {
      res.redirect('/login');
    }
  });
});

// Přihlášení
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const query = "SELECT * FROM users WHERE username = ? AND password = ?";
  db.get(query, [username, password], (err, user) => {
    if (err) {
      console.error(err);
      res.send("Chyba při přihlašování");
    } else if (user) {
      req.session.user = {
        id: user.id,
        username: user.username,
        is_vip: user.is_vip == 1
      };
      res.redirect('/');
    } else {
      res.send("Neplatné přihlašovací údaje");
    }
  });
});

// Odhlášení
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Middleware kontrolující, zda je uživatel přihlášen
function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  next();
}

// Přidání produktu do košíku – pouze pro přihlášeného uživatele
app.post('/add-to-cart', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const productId = req.body.product_id;
  db.get("SELECT * FROM cart WHERE user_id = ? AND product_id = ?", [userId, productId], (err, row) => {
    if (err) {
      console.error(err);
      res.send("Chyba při přidávání do košíku");
    } else if (row) {
      db.run("UPDATE cart SET quantity = quantity + 1 WHERE id = ?", [row.id], function(err) {
        if (err) {
          console.error(err);
          res.send("Chyba při aktualizaci košíku");
        } else {
          res.redirect('/');
        }
      });
    } else {
      db.run("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)", [userId, productId, 1], function(err) {
        if (err) {
          console.error(err);
          res.send("Chyba při přidávání do košíku");
        } else {
          res.redirect('/');
        }
      });
    }
  });
});

// Zobrazení košíku
app.get('/cart', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const query = `
    SELECT p.id AS product_id, c.quantity, p.name, p.price, p.imagePath
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
  `;
  db.all(query, [userId], (err, cartItems) => {
    if (err) {
      console.error(err);
      res.send("Chyba při načítání košíku");
    } else {
      res.render('cart', { cartItems: cartItems });
    }
  });
});

// Zvýšení počtu kusů produktu v košíku
app.post('/cart/increase', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const productId = req.body.product_id;
  db.run(
    "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?",
    [userId, productId],
    function(err) {
      if (err) {
        console.error(err);
        res.send("Chyba při aktualizaci košíku");
      } else {
        res.redirect('/cart');
      }
    }
  );
});

// Snížení počtu kusů produktu v košíku – pokud klesne na nulu, záznam se odstraní
app.post('/cart/decrease', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const productId = req.body.product_id;
  db.get(
    "SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?",
    [userId, productId],
    (err, row) => {
      if (err) {
        console.error(err);
        return res.send("Chyba při získávání informací o položce v košíku");
      }
      if (!row) {
        return res.redirect('/cart');
      }
      if (row.quantity > 1) {
        db.run(
          "UPDATE cart SET quantity = quantity - 1 WHERE user_id = ? AND product_id = ?",
          [userId, productId],
          function(err) {
            if (err) {
              console.error(err);
              res.send("Chyba při aktualizaci košíku");
            } else {
              res.redirect('/cart');
            }
          }
        );
      } else {
        // Pokud je množství 1, položku odstraníme
        db.run(
          "DELETE FROM cart WHERE user_id = ? AND product_id = ?",
          [userId, productId],
          function(err) {
            if (err) {
              console.error(err);
              res.send("Chyba při odstraňování produktu z košíku");
            } else {
              res.redirect('/cart');
            }
          }
        );
      }
    }
  );
});
// Route pro vložení nového produktu do databáze
app.post('/products/add', (req, res) => {
  const { name, price, imagePath } = req.body;
  // Pro jednoduchost používáme prázdný popis – můžete ho rozšířit
  const description = "";
  const query = "INSERT INTO products (name, description, price, imagePath) VALUES (?, ?, ?, ?)";
  db.run(query, [name, description, price, imagePath], function(err) {
    if (err) {
      console.error(err);
      res.send("Chyba při přidávání produktu: " + err.message);
    } else {
      res.redirect('/');
    }
  });
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server běží na portu http://localhost:${PORT}`);
});
