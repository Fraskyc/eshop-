const express = require('express');
const session = require('express-session');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'secret-key',
  resave: false,
  saveUninitialized: false
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Inicializace databáze
const dbPath = path.join(__dirname, 'database', 'eshop.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) console.error("DB Error: ", err.message);
  else console.log("Connected to SQLite database");
});

// Vytvoření tabulek, pokud neexistují
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      description TEXT,
      price REAL,
      imagePath TEXT
  )`);
  
  db.run(`CREATE TABLE IF NOT EXISTS cart (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      product_id INTEGER,
      quantity INTEGER,
      FOREIGN KEY(product_id) REFERENCES products(id)
  )`);
});

// Přidání produktu do košíku
app.post('/add-to-cart', (req, res) => {
  const userId = req.session.user ? req.session.user.id : null;
  const productId = req.body.product_id;

  if (!userId) {
    return res.redirect('/login');
  }

  db.get("SELECT * FROM cart WHERE user_id = ? AND product_id = ?", [userId, productId], (err, row) => {
    if (err) {
      console.error(err);
      res.send("Chyba při přidávání do košíku");
    } else if (row) {
      db.run("UPDATE cart SET quantity = quantity + 1 WHERE id = ?", [row.id], function(err) {
        if (err) {
          console.error(err);
          res.send("Chyba při aktualizaci košíku");
        } else {
          res.redirect('/');
        }
      });
    } else {
      db.run("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)", [userId, productId, 1], function(err) {
        if (err) {
          console.error(err);
          res.send("Chyba při přidávání do košíku");
        } else {
          res.redirect('/');
        }
      });
    }
  });
});

// Zobrazení košíku
app.get('/cart', (req, res) => {
  const userId = req.session.user ? req.session.user.id : null;

  if (!userId) {
    return res.redirect('/login');
  }

  const query = `
    SELECT p.id AS product_id, c.quantity, p.name, p.price, p.imagePath
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
  `;
  db.all(query, [userId], (err, cartItems) => {
    if (err) {
      console.error(err);
      res.send("Chyba při načítání košíku");
    } else {
      res.render('cart', { cartItems: cartItems });
    }
  });
});

// Hlavní stránka
app.get('/', (req, res) => {
  db.all("SELECT * FROM products", (err, products) => {
    if (err) {
      console.error(err);
      res.send("Error loading products");
    } else {
      res.render('index', { products: products });
    }
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server běží na portu http://localhost:${PORT}`);
});
